@echo off
cd /d "%~dp0"
for %%f in ("desktop\*.exe") do (
  start "" "%%~ff"
  exit /b
)
echo desktop launcher not found
pause
