# 课表 SuperTable

当前版本：**3.2.3**

一款移动端优先的课程表应用：周课表、日程待办、教务系统导入、空教室、校历与分享。
界面参考国内主流课表类 App 的交互习惯重新实现（周次条、彩色课程块、底部五栏导航、导入向导），代码与视觉资产均为原创，不包含任何第三方 App 的素材。

> 首次安装为**空课表**，不预置任何示例课程；导入本学期课表后即可按周查看。

<p align="center">
  <img src="docs/screenshots/timetable.png" width="240" alt="课表">
  <img src="docs/screenshots/agenda.png" width="240" alt="日程">
  <img src="docs/screenshots/tools.png" width="240" alt="工具">
</p>

## 功能

- **周课表**：20 周（可设置 16–24 周）横向周次条、左右滑动切周、回到本周、今日高亮、当前时间红线、重叠课程自动分栏、点击空白格直接添加。
- **课程管理**：课程名 / 教师 / 地点 / 星期 / 节次 / 周次（支持单双周、任意周次组合）/ 颜色 / 备注；实时冲突提示；删除与修改。
- **教务系统导入**：正方新版（RSA 登录 + 课表接口）、正方旧版（ASP.NET + 验证码）、自定义 JSON 接口；导入前逐条预览，支持「合并」与「覆盖」。
- **网页登录导入（Android）**：可填写/修改教务系统网址，App 内置浏览器打开后由你亲自登录，打开课表后点「导入当前课表」一键导入，App 不保存密码。
- **兜底导入**：粘贴课表网页源码（自动解析正方表格）、JSON、CSV，或导入文件、同学分享码。
- **日程**：今日课程时间轴（含晚自习）、待办事项（勾选 / 删除 / 截止日期）、未来 6 天课程与晚自习预告。
- **工具**：空教室推算、校历（教学周 + 有课标记）、分享码生成、CSV / ICS / JSON 导出与备份恢复。
- **其他**：深色模式、上课提醒（Android 系统通知，非闹钟；网页端浏览器通知）、学期设置（开学日期 / 周数 / 每日节数与上下课时间）、PWA 离线可用、数据全部本地存储。
- **晚自习**：可在学期设置中选择周一至周日的任意日期，自定义时间、名称、显示信息与颜色；课表与日程同步显示，与上课时间冲突时显示课程。
- **Android App**：独立 APK，内置本地导入代理，手机端无需电脑即可从教务系统导入。

<p align="center">
  <img src="docs/screenshots/import-preview.png" width="240" alt="导入预览">
  <img src="docs/screenshots/calendar.png" width="240" alt="校历">
  <img src="docs/screenshots/dark.png" width="240" alt="深色模式">
</p>

## 快速开始

要求 **Node.js 20+**（使用内置 `fetch`、`AbortSignal.timeout`、`getSetCookie`）。

**Windows 一键启动**：双击应用目录下的 `一键启动课表.bat`（或 `desktop\课表SuperTable.exe`），会自动启动本地服务并以独立窗口打开课表。

**命令行启动**：

```bash
cd super-timetable
npm start            # 或 node server/index.js
# 打开 http://127.0.0.1:5178
```

- 换端口：`PORT=8080 npm start`（Windows PowerShell：`$env:PORT=8080; npm start`）。
- 只浏览课表、不用教务系统导入时，也可以用任意静态服务器（如 `python -m http.server 8000`）；**不要直接双击 `index.html`**，浏览器会拦截 `file://` 下的 ES 模块。静态方式下「账号导入」不可用，但粘贴 / 文件 / 分享码导入仍可用。
- 首次打开为空课表，可通过右上角导入教务系统，或点空白格手动添加课程。

## 武汉纺织大学外经贸学院（已适配）

应用已内置该校预设，导入时只需选择学校、填写学号与密码：

| 项目 | 值 |
| --- | --- |
| 教务系统 | 正方 V9「教学管理信息服务平台」 |
| 地址 | `http://jw.whcibe.com` |
| 登录页 | `/xtgl/login_slogin.html`（RSA + Base64 公钥） |
| 课表接口 | `/kbcx/xskbcx_cxXsgrkb.html?gnmkdm=N2151` |
| 网络 | 公网可访问，无需校园网 |

**校历与作息（已内置为默认值）：**

- 学期第 1 周周一 = **2026-09-07**，2026-09-10（周四）进校，因此 2026-10-21（周三）为 **第 7 周**。
- 上课时间共 **10 节**（上午 4 节 + 下午/晚间 6 节），每节 45 分钟：

| 节次 | 时间 | 节次 | 时间 |
| --- | --- | --- | --- |
| 第 1 节 | 08:15 - 09:00 | 第 6 节 | 14:20 - 15:05 |
| 第 2 节 | 09:05 - 09:50 | 第 7 节 | 15:25 - 16:10 |
| 第 3 节 | 10:10 - 10:55 | 第 8 节 | 16:15 - 17:00 |
| 第 4 节 | 11:00 - 11:45 | 第 9 节 | 17:45 - 18:30 |
| 第 5 节 | 13:30 - 14:15 | 第 10 节 | 18:35 - 19:20 |

- **晚自习**：默认周一至周四，19:30 - 21:30，名称与显示信息可在「我的 → 学期设置」中自定义。课表上晚自习与上课时间冲突时显示课程，未冲突时显示晚自习。

已实测：本机服务能够访问学校登录页、获取公钥、完成 RSA 加密并提交登录。使用错误账号时，学校返回原文「用户名或密码不正确，请重新输入！」并显示在导入向导中，说明加密与登录链路已打通。课表属于个人数据，需要你用真实学号密码完成首次导入，导入前可逐条预览。

如果学校后续升级导致接口变化：在导入向导中改用「粘贴课表网页」——登录教务系统后按 `Ctrl+U` 复制课表页源码即可解析；也可以在浏览器开发者工具中复制课表接口返回的 JSON 粘贴导入。

<p align="center">
  <img src="docs/screenshots/import-school.png" width="260" alt="学校预设">
</p>

## 作为 App 运行

### Android 手机 App（vivo X300 Ultra / Android 8.0+）

安装包：**[dist/课表SuperTable.apk](dist/课表SuperTable.apk)**（约 0.15 MB，minSdk 26，targetSdk 34）
便携安装包（APK + 安装说明）：**[dist/课表SuperTable-Android.zip](dist/课表SuperTable-Android.zip)**

- **完全独立运行**：课表页面、静态资源、教务系统代理都打包在 APK 内，不需要电脑、不需要 Node.js。
- 已内置武汉纺织大学外经贸学院（正方 V9）预设，输入学号密码即可导入。
- 本地代理运行在 App 内（`127.0.0.1` 随机端口），账号密码只在一次导入中使用，不写入磁盘。
- 支持文件导入（系统文件选择器）、分享码、CSV/ICS、导出到手机“下载”目录。
- 返回键会先关闭弹层/回到课表，再退出 App。

<p align="center">
  <img src="docs/screenshots/android.png" width="260" alt="Android App">
</p>

**vivo / OriginOS 安装步骤：**

1. 将 `课表SuperTable.apk` 传到手机（数据线、微信文件传输、网盘均可）。
2. 打开「设置 → 应用与权限 → 特殊应用权限 → 安装未知应用」，允许文件管理或浏览器安装应用。
3. 点击 APK 安装；若出现“未知来源”或 Play 保护提示，选择「仍要安装 / 继续」。
4. 打开「课表 SuperTable」，进入「我的 → 导入课表」，可选「网页登录导入」（App 内登录后一键导入）或「账号导入」（输入学号密码）。

**自行构建：**

```powershell
# 需要 JDK 17 + Android SDK（platforms;android-34、build-tools;34.0.0）
cd android
$env:JAVA_HOME = "C:\Program Files\Java\jdk-17"
$env:ANDROID_SDK_ROOT = "E:\AndroidSdk"
powershell -ExecutionPolicy Bypass -File .\build.ps1
```

签名密钥为 `android/keystore.jks`（口令 `supertable123`），升级安装请保留同一密钥。

> 已在 Android 9 模拟器上实测：启动、课表渲染、导入向导、真实学校登录错误提示、模拟成功导入预览、返回键关闭弹层，均正常。vivo X300 Ultra 为 Android 16，使用相同 WebView 与网络栈。课表抓取需要用你的真实账号完成首次导入。

### Windows 桌面 App

`desktop/课表SuperTable.exe` 是桌面启动器：双击后自动启动本地服务，并用 Edge / Chrome 的独立应用窗口打开课表，任务栏显示独立图标与标题。

- 首次使用建议运行 `desktop/安装到桌面.bat`，在桌面创建带图标的快捷方式。
- 需要 Node.js 20+（启动器会自动查找 `node.exe`；也可以把 `node.exe` 放到 `desktop/runtime/` 随应用携带）。
- `desktop/停止课表.bat` 停止后台服务；`desktop/启动课表.bat` 是等价的命令行启动方式。
- 便携包：`dist/课表SuperTable-win.zip`，解压后直接运行 `desktop/课表SuperTable.exe`。

### 手机 / 平板 PWA

在浏览器中打开应用 → 菜单 → 「安装应用 / 添加到主屏幕」，即可像原生 App 一样全屏使用。应用内「我的 → 安装到桌面 / 手机」会显示当前平台的安装步骤。

> 手机端使用教务系统导入时，需要能访问运行本地服务的电脑：在电脑上执行 `HOST=0.0.0.0 npm start`（PowerShell：`$env:HOST='0.0.0.0'; npm start`），手机打开 `http://电脑局域网IP:5178` 后安装到主屏幕。此时账号密码会经局域网发送到电脑上的本地服务再转发给学校，请只在可信网络中使用；只查看课表则不必开启局域网访问。

## 导入课表

导入入口：课表页右上角 ⤒、「我的 → 导入课表」，或「工具 → 导入课表」。

### 1. 网页登录导入（推荐，Android App）

在 App 内点「网页登录导入」，App 会打开教务系统登录页：

1. 你自己输入学号、密码（或扫码）登录，密码不经过 App 保存；
2. 打开「课表查询」页面；
3. 点页面下方的 **「导入当前课表」** 按钮。

App 会优先读取你当前页面里已经渲染出来的课表表格；如果页面结构特殊，会使用 WebView 的登录 Cookie 调用学校课表接口作为兜底。导入后先预览，再选择合并或覆盖。

> 电脑/网页版没有内置浏览器，请使用「账号导入」，或登录后复制课表网页源码用「粘贴课表网页」导入。

### 2. 正方教务系统（账号导入）

| 版本 | 地址示例 | 说明 |
| --- | --- | --- |
| 新版（jwglxt / V9） | `http://jw.whcibe.com` | 自动获取 RSA 公钥（Base64 或十六进制）加密密码，登录后调用 `kbcx/xskbcx_cxXsgrkb.html`，兼容 `sjkList` 实践课 |
| 旧版（ASP.NET） | `https://jw.example.edu.cn` | 解析 `__VIEWSTATE` 登录，抓取 `xskbcx.aspx` 页面，支持验证码图片 |

流程：选择学校（或填写系统类型与地址）→ 学号、密码、学年与学期 → 开始导入 → 若提示验证码则输入图片验证码 → 预览课程 → 合并或覆盖。

> 各校部署差异很大：可能修改接口路径、要求教学评价、限制校园网、启用双因素认证或图形验证码。自动导入失败时，请在错误提示下点击「改用粘贴课表网页」，或在浏览器中登录后复制课表页面源码解析。适配器无法在未持有学校账号的情况下验证，请以实际学校系统为准。

### 3. 自定义课表接口

提供一个返回 JSON 的 URL（可选 Cookie）。支持以下形状，自动识别：

```json
{ "kbList": [ { "kcmc": "高等数学", "xm": "张伟", "cdmc": "教一101",
  "xqj": "1", "jcs": "1-2节", "zcd": "1-16周" } ] }
```

```json
{ "data": [ { "courseName": "大学物理", "teacherName": "刘洋",
  "classroomName": "理科楼401", "dayOfWeek": 2,
  "classTime": "5-6节", "weekDescription": "1-14周" } ] }
```

也接受中文键名：`课程名称 / 教师 / 地点 / 星期 / 节次 / 周次`，以及数组根节点。

### 4. 粘贴 / 文件 / 分享码

- **粘贴课表网页**：在已登录的教务系统课表页按 `Ctrl+U` 查看源码，全选复制粘贴；解析器会识别「星期 × 节次」表格与列表式表格。
- **CSV**：表头需包含 `课程名,教师,教室,星期,节次,周次,备注`；星期支持 `周一 / 星期一 / 1`，节次支持 `1-2节 / 第1-2节`，周次支持 `1-16周 / 1-15周(单) / 1-8,10-16周`。
- **ICS**：支持本应用导出的日历文件（带周次与节次描述）。
- **分享码**：`ST1.` 开头的字符串，同学在「分享码导入」粘贴即可，不含账号信息。

## 数据与隐私

- 课表、待办、设置保存在浏览器 `localStorage`（键名 `supertable.state.v1`），不上传任何第三方服务器。
- 教务系统账号密码只在本机服务的一次导入请求中使用，保存在内存会话里，**不写入磁盘、不写日志**；会话 10 分钟过期。
- 导入服务只向用户填写的教务地址发起 HTTPS/HTTP 请求；请自行确认学校系统的使用条款。
- 建议在公共电脑上使用后「我的 → 清空课表」并清除站点数据。

## 目录结构

```
super-timetable/
├── index.html                 单页应用外壳
├── css/style.css              全部样式（移动优先 + 深色模式）
├── js/
│   ├── app.js                 入口：路由、顶栏、底部导航、提醒
│   ├── schedule.js            周次 / 节次 / 日期 / 冲突 / 布局（纯函数）
│   ├── importers.js           JSON / CSV / ICS / 分享码解析与导出（纯函数）
│   ├── zf-html.js             教务系统课表网页解析（DOMParser）
│   ├── store.js               localStorage 状态与业务动作
│   ├── ui.js                  图标、弹层、确认框、Toast
│   ├── install.js             PWA 安装支持
│   └── views/                 timetable / detail / editor / agenda / tools / me / import
├── server/
│   ├── index.js               静态站点 + /api/import 代理
│   ├── api.js                 会话管理与适配器调度
│   ├── adapters/              zfsoft / zfsoft-old / custom
│   └── lib/                   Cookie 罐、RSA 公钥加密（兼容 Base64 / Hex）
├── desktop/                   Windows 启动器、图标与快捷方式脚本
├── test/                      单元测试（Node 内置 test runner）
├── scripts/                   CDP 端到端脚本（开发用）
└── manifest.webmanifest, sw.js, icons/
```

## 开发与测试

```bash
npm test          # 23 个单元测试：周次、节次、冲突、车道、JSON/CSV/ICS/分享码、RSA（Hex/Base64）、导入会话
node scripts/check-modules.mjs   # 检查所有前端模块可正确链接
```

端到端测试使用 Chrome DevTools Protocol 驱动真实页面（需先启动服务并以 `--remote-debugging-port=9333` 启动 Edge/Chrome）：

```bash
node scripts/e2e.mjs      # 添加 / 编辑 / 删除课程、学期设置、深色模式、工具弹层、CSV 导入、切周
node scripts/ui-shots.mjs # 生成各页面截图
```

## 数据与安全

- 课表与用户设置保存在本机，关闭 App 后重新打开仍会保留；本地服务使用固定端口，避免 origin 变化导致数据丢失。
- Android 上课提醒使用系统通知 + AlarmManager（`setExactAndAllowWhileIdle`），不使用闹钟/`setAlarmClock`；重启手机后自动恢复。
- APK 使用 R8 混淆、Web 资源 AES-256-GCM 加密、运行时签名校验与调试检测，降低二次打包、注入与静态分析风险。
- 二次加固：使用 XopProtector 0.6.26 对 DEX 加密并注入原生壳（arm64-v8a / armeabi-v7a），详见 [PROTECT.md](PROTECT.md)；x86 设备不适用。
- 需要说明：个人项目无法做到绝对不可逆向，以上措施用于提高破解与二次打包成本。

Built by Luoz1337

## 已知限制

- 教务系统适配器是「尽力而为」实现：不同学校、不同年份的系统版本都可能不同，无法保证全部学校开箱即用；失败时请使用粘贴网页 / CSV / 分享码。
- 武汉纺织大学外经贸学院的登录链路已实测，但课表抓取需要本人账号完成首次验证；若学校调整接口或要求教学评价，可能需要在导入向导里改用粘贴网页。
- 不支持成绩查询、考场查询、校园资讯等需要额外教务接口的功能；没有原生小组件。
- 空教室结果只根据已导入课程推算，不代表学校全部教室的实时占用。
- 分享码为明文 Base64 编码，仅用于同学间分享课表，不要在其中加入敏感信息。
- 本项目与「超级课程表」等任何商业 App 无关联，未使用其商标、图标或代码。

## License

MIT（示例数据与文案可自由修改）。
